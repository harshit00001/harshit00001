package Day12.Assignment1;

public class Grosery extends Shopping {

	public Grosery(String item, int price) {
		super(item, price);
		// TODO Auto-generated constructor stub
	}
	

}
