package Day12.Assignment1;

public class Kids extends Shopping{

	public Kids(String item, int price) {
		super(item, price);
		// TODO Auto-generated constructor stub
	}
	

}
