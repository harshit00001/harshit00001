package Day12.Assignment1;

public class Electronics extends Shopping{

	public Electronics(String item, int price) {
		super(item, price);
		// TODO Auto-generated constructor stub
	}
	

}
