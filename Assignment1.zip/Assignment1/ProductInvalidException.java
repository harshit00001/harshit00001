package Day12.Assignment1;

public class ProductInvalidException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProductInvalidException(String str)
	{
		super(str);
	}

}
