package Day9.Assignment2;

public class TableMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new TableOddEven("Thread 1: ");

	}

}
