package Day7.Assignment1;

public class CustomException extends Exception{
	public CustomException(String str)
	{
		super(str);
	}

}
