package Day3.Assignment1;

public class MainOverload {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodOverload m=new MethodOverload();
		m.arg(2,5);
		m.arg(2,5,7);
		m.arg(2,5,7,9);
		
	}

}
