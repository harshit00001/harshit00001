package Day3.Assignment2;

public interface Sport {
		void getName();
}
