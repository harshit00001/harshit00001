package Day3.Assignment3;
public class MainAnimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bird A1=new Bird();
		A1.fly();
		A1.sleep();
		A1.eat();
	}

}
