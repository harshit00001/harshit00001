package Day3.Assignment3;

public class Bird extends Animal{
	public void fly()
	{
		System.out.println("Bird Fly");
	}
	public void eat()
	{
		System.out.println("Bird eat");
	}
	public void sleep()
	{
		System.out.println("Bird Sleep");
	}

}
