package Day3.Assignment3;

public class Animal {
	public void eat()
	{
		System.out.println("Animal eat");
	}
	public void sleep()
	{
		System.out.println("Animal Sleep");
	}

}
