package Day10.Assignment1;

public class CustomExce extends Exception {
	public CustomExce(String str)
	{
		super(str);
	}

}
