package Day3;

public class Animal {
	public void eat()
	{
		System.out.println("Animal eat");
	}
	public void sleep()
	{
		System.out.println("Animal Sleep");
	}

}
