package day2;

public interface Sport {
		void getName();
}
