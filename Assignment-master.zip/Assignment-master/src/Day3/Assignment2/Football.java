package day2;

public class Football implements Sport {

	@Override
	public void getName() {
		// TODO Auto-generated method stub
		System.out.println("Sport:  Football");
	}

}
