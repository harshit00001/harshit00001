package day2;

public class Badminton implements Sport {

	@Override
	public void getName() {
		// TODO Auto-generated method stub
		System.out.println("Sport:  Badminton");
	}

}
