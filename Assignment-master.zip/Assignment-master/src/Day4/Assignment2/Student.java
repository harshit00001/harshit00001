package Day4;

public abstract class Student {
	public String department,student_name;
	public int hostel_number,room_number,registration_No;
	abstract String getStudentDetails();

}
