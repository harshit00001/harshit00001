package Day4;

public class DayScholars extends Student{

	@Override
	String getStudentDetails() {
		// TODO Auto-generated method stub
			return "Student Name: "+ student_name +"\nDepartment: " + department;	
	}
}
