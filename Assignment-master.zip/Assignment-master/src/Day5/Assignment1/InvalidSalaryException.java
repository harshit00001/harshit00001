package Day5;
import java.lang.*;
public class InvalidSalaryException extends Exception {
	public InvalidSalaryException(String str)
	{
		super(str);
	}
}
