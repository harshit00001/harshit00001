package Day10;

public class CustomExce extends Exception {
	public CustomExce(String str)
	{
		super(str);
	}

}
