package Day9;

public class PriorityMainThread{
	public static void main(String[] args) { 
			new PriorityThread("Thread 1",1);
			new PriorityThread("Thread 2",8);
			new PriorityThread("Thread 3",2);
			new PriorityThread("Thread 4",10);

	}

}
