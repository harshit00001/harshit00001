package Day7;

public class CustomException extends Exception{
	public CustomException(String str)
	{
		super(str);
	}

}
