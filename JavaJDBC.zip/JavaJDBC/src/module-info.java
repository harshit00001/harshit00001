module JavaJDBC {
	requires java.sql;
	requires ojdbc6;
}